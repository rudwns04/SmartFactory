"""
Motion detector module
"""

from iotdemo.motion.motion_detector import MotionDetector

__all__ = ('MotionDetector', )
